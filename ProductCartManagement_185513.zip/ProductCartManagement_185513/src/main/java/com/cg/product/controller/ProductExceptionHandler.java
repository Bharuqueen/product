package com.cg.product.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.product.exception.ProductException;

public class ProductExceptionHandler {
	 @ExceptionHandler(ProductException.class)
		public ResponseEntity <String> handleException(Exception ex){
			return new ResponseEntity <String> ("Error : "+ex.getMessage(), HttpStatus.CONFLICT);
	   }

}
