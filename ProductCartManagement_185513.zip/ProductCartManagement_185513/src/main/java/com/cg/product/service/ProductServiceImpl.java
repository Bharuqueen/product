package com.cg.product.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.bean.Product;
import com.cg.product.dao.IProductRepo;
import com.cg.product.exception.ProductException;



@Service
public class ProductServiceImpl implements IProductService{
	@Autowired
IProductRepo Productrepo;
	
	@Override
	public List<Product> getAllProducts() throws ProductException {
	try
	{
		return Productrepo.findAll();
	}
	catch(Exception e)
	{
		throw new ProductException(e.getMessage());
	}
		
	}

	@Override
	public Product getProductById(String id) throws ProductException {
		try
		{
			return Productrepo.findById(id).get();
		}
		catch (Exception ex)
		{
			throw new ProductException("Product with Id"+id+" does not exist");
		}
	}

	

	@Override
	public void deleteProduct(String id) throws ProductException {
		try
		{
			Productrepo.deleteById(id);
		}
		catch(Exception e)
		{
			throw new ProductException("Product with Id"+id+" does not exist");
		}
	}

	@Override
	public List<Product> CreateProduct(Product pro) throws ProductException {
		 try {
			 Productrepo.save(pro);
			 
		        return Productrepo.findAll();
		        }catch(Exception e) {
		            throw new ProductException(e.getMessage());
		        }
		        }
		
	
			@Override
			public List<Product> updateProduct(String id, Product pro)throws ProductException {
		        try {
		            Optional<Product> optional =Productrepo.findById(id);
		            if(optional.isPresent()) {
		                Product prod = optional.get();

		                prod.setName(pro.getName());
		                prod.setModel(pro.getModel());
		                prod.setPrice(pro.getPrice());
		                Productrepo.save(prod);
		                return getAllProducts();
		            }
		            else
		                throw new ProductException("Product with ID " + id + " does not exist.");
		        } catch (Exception e) {
		            throw new ProductException(e.getMessage());
		        }
			}
}
		
	




